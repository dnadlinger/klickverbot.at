from __future__ import division
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import numpy as np

# Read image.
M = mpimg.imread('eth.png')
source_count = np.prod(M.shape)
print "Source consists of", source_count, "elements."

# Compute SVD.
U, s, V = np.linalg.svd(M, full_matrices = False)

# Reduce amount of data (this result of this step is what would be
# stored/transmitted instead of the whole matrix.
n = 40
U_comp = U[:, :n]
s_comp = s[:n]
V_comp = V[:n, :]

reduced_count = sum(map(lambda x: np.prod(x.shape), [U_comp, s_comp, V_comp]))
print "SVD with first", n, "singular values consists of", reduced_count, "elements."
print "This is", reduced_count / source_count, "times the original size."

# Reconstruct image from compressed data.
S_comp = np.diag(s_comp)
M_comp = np.dot(U_comp, np.dot(S_comp, V_comp))

# Plot original image.
plt.subplot(2, 2, 1)
plt.imshow(M, cmap=plt.cm.Greys_r)
plt.title('Original image');
plt.axis('off')

# Plot image.
plt.subplot(2, 2, 2)
plt.imshow(M_comp, cmap=plt.cm.Greys_r)
plt.title('Image reconstructed from the first %s singular values' % n);
plt.axis('off')

# Plot difference between original and reconstruction.
plt.subplot(2, 2, 3)
plt.imshow(np.abs(M_comp - M), cmap = plt.cm.Greys_r)
plt.colorbar(orientation = 'horizontal', shrink = 0.9, pad = 0.01)
plt.title('Difference between original and reconstruction');
plt.axis('off')

# Graph singular values
plt.subplot(2, 2, 4)
plt.semilogy(s)
plt.title('Singular values')
plt.show()

