#include "demo.h"

#include <sstream>

Position Shape::getPosition() const {
   return m_position;
}

std::string Circle::getDescription() const {
   return "A perfect circle.";
} 

std::string toString( const Shape& shape ) {
   std::ostringstream result;

   Position p = shape.getPosition();
   result << "A shape at (" << p.first << ", " << p.second << ").";
   result << " It looks like this: " << shape.getDescription();

   return result.str();
}
