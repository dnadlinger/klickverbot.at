#include <string>
#include <utility>

typedef std::pair<float, float> Position;

class Shape {
public:
   Shape( Position pos ) : m_position( pos ) {}
   virtual ~Shape() {}

   virtual std::string getDescription() const = 0;
   Position getPosition() const;

private:
   Position m_position;
};

class Circle : public Shape {
public:
   Circle( Position pos ) : Shape( pos ) {}
   virtual std::string getDescription() const;
};

std::string toString( const Shape& shape );
